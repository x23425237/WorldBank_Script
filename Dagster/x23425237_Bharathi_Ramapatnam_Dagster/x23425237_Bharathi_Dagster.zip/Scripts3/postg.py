import psycopg2
from dagster import op
from sqlalchemy import create_engine, text

# Connection string
conn_str = "postgresql://postgres:dap@localhost:5432/postgres"

@op
def create_database_and_tables(context):
    conn = None  # To store the connection object

    # Step 1: Establishing the connection using psycopg2 for version check
    try:
        connection = psycopg2.connect(conn_str)
        cursor = connection.cursor()

        # Sample query to test the connection
        cursor.execute("SELECT version();")

        # Fetching the result
        db_version = cursor.fetchone()
        context.log.info(f"Connected to PostgreSQL, version: {db_version[0]}")

        # Close the psycopg2 connection
        cursor.close()
        connection.close()

    except Exception as e:
        context.log.error(f"Error connecting to PostgreSQL: {e}")
        raise

    # Step 2: Now, use SQLAlchemy to create a new database
    engine = create_engine(conn_str)

    # Define the SQL statement for creating the loan_data_historical table
    loan_data_table_create_string = """
    CREATE TABLE loan_data (
        end_of_period DATE,                                 
        loan_number VARCHAR(50),                             
        region VARCHAR(100),                                 
        country_economy_code VARCHAR(10),                    
        country_economy VARCHAR(100),                        
        borrower VARCHAR(255),                               
        guarantor_country_economy_code VARCHAR(10),          
        guarantor VARCHAR(255),                              
        loan_type VARCHAR(100),                               
        loan_status VARCHAR(50),                             
        interest_rate DECIMAL(5, 2),                          
        currency_of_commitment VARCHAR(3),                   
        project_id VARCHAR(50),                              
        project_name VARCHAR(255),                            
        original_principal_amount_usd DECIMAL(15, 2),        
        cancelled_amount_usd DECIMAL(15, 2),                 
        undisbursed_amount_usd DECIMAL(15, 2),               
        disbursed_amount_usd DECIMAL(15, 2),                 
        repaid_to_ibrd_usd DECIMAL(15, 2),                   
        due_to_ibrd_usd DECIMAL(15, 2),                      
        exchange_adjustment_usd DECIMAL(15, 2),             
        borrowers_obligation_usd DECIMAL(15, 2),             
        sold_3rd_party_usd DECIMAL(15, 2),                   
        repaid_3rd_party_usd DECIMAL(15, 2),                 
        due_3rd_party_usd DECIMAL(15, 2),                    
        loans_held_usd DECIMAL(15, 2),                       
        first_repayment_date DATE,                           
        last_repayment_date DATE,                            
        agreement_signing_date DATE,                        
        board_approval_date DATE,                            
        effective_date DATE,                                 
        closed_date DATE,                                    
        last_disbursement_date DATE                          
    );
    """

    eco_indicator_table_create_string = """
    CREATE TABLE world_eco_indicator (
        Country_Name VARCHAR(255),                          
        Country_Code CHAR(3),                                
        Region VARCHAR(255),                                 
        IncomeGroup VARCHAR(255),                            
        Year INT,                                            
        Birth_rate_crude DECIMAL(5,2),                       
        Death_rate_crude DECIMAL(5,2),                       
        Electric_power_consumption DECIMAL(10,2),            
        GDP DECIMAL(20,2),                                   
        GDP_per_capita DECIMAL(20,2),                        
        Individuals_using_Internet DECIMAL(5,2),             
        Infant_mortality_rate DECIMAL(5,2),                  
        Life_expectancy_at_birth DECIMAL(5,2),               
        Population_density DECIMAL(10,2),                    
        Unemployment_rate DECIMAL(5,2)                       
    );
    """

    # Establishing the connection using SQLAlchemy
    try:
        with engine.connect() as connection:
            # Setting the isolation level to AUTOCOMMIT for database creation
            connection.execution_options(isolation_level="AUTOCOMMIT")

            # Executing the SQL command to create the database
            connection.execute(text("CREATE DATABASE worldbank_dg;"))
            context.log.info("Database 'worldbank_dg' created successfully.")

            # After database creation, switch connection to the new database
            new_engine = create_engine("postgresql://postgres:dap@localhost:5432/worldbank_dg")

            # Create the loan_data_historical table
            with new_engine.connect() as new_connection:
                new_connection.execute(text(loan_data_table_create_string))
                context.log.info("Table 'loan_data' created successfully.")

                # Create the world_eco_indicator table
                new_connection.execute(text(eco_indicator_table_create_string))
                context.log.info("Table 'world_eco_indicator' created successfully.")

                # Return a success message instead of the connection object
                return "Database and tables created successfully."

    except Exception as e:
        context.log.error(f"Error during database/table creation: {e}")
        raise
