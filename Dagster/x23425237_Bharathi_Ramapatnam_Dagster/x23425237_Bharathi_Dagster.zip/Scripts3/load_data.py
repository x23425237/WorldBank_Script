import psycopg2
from dagster import op

# Define the operation (task) using the @op decorator
@op
def load_loan_and_worldbank_data_to_postgres(context, message, output_csv_path):
    # Log the incoming message
    print(f"Processing message: {message}")
    
    # Database connection parameters
    conn_params = {
        "dbname": "worldbank",
        "user": "postgres",
        "password": "dap",
        "host": "localhost",
        "port": "5432"
    }

    # Initialize connection and cursor
    conn = None
    cursor = None
    
    try:
        # Establishing the connection
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()

        # Prepare the COPY SQL command for loan data
        copy_sql_loan_data = """
            COPY loan_data (
                end_of_period, loan_number, region, country_economy_code, country_economy, 
                borrower, guarantor_country_economy_code, guarantor, loan_type, loan_status, 
                interest_rate, currency_of_commitment, project_id, project_name, 
                original_principal_amount_usd, cancelled_amount_usd, undisbursed_amount_usd, 
                disbursed_amount_usd, repaid_to_ibrd_usd, due_to_ibrd_usd, 
                exchange_adjustment_usd, borrowers_obligation_usd, sold_3rd_party_usd, 
                repaid_3rd_party_usd, due_3rd_party_usd, loans_held_usd, 
                first_repayment_date, last_repayment_date, agreement_signing_date, 
                board_approval_date, effective_date, closed_date, last_disbursement_date
            ) 
            FROM stdin WITH CSV HEADER DELIMITER as ',' 
        """

        # Prepare the COPY SQL command for world_eco_indicator data
        copy_sql_worldbank = """
            COPY world_eco_indicator (
                Country_Name, Country_Code, Region, IncomeGroup, Year, 
                Birth_rate_crude, Death_rate_crude, Electric_power_consumption, 
                GDP, GDP_per_capita, Individuals_using_Internet, 
                Infant_mortality_rate, Life_expectancy_at_birth, 
                Population_density, Unemployment_rate
            ) 
            FROM stdin WITH CSV HEADER DELIMITER as ',' 
        """

        # Load the loan_data CSV file
        try:
            with open(output_csv_path, 'r') as f:
                cursor.copy_expert(sql=copy_sql_loan_data, file=f)
            context.log.info("Loan data loaded successfully.")
        except FileNotFoundError:
            context.log.error(f"Loan data file not found: {output_csv_path}")
            raise

        # Assuming world_eco_file_path is another input or fixed location, here it's hardcoded
        world_eco_file_path = 'C:/Users/prana/Documents/NCI/PythonWorkSpace/WorldBank/Data/WorldBank.csv'

        # Load the world_eco_indicator CSV file
        try:
            with open(world_eco_file_path, 'r') as f:
                cursor.copy_expert(sql=copy_sql_worldbank, file=f)
            context.log.info("World eco indicator data loaded successfully.")
        except FileNotFoundError:
            context.log.error(f"World eco indicator file not found: {world_eco_file_path}")
            raise

        # Commit the transaction to the database
        conn.commit()
        context.log.info("Transaction committed successfully.")

    except Exception as e:
        # Log any errors
        context.log.error(f"Error loading data: {e}")
        if conn:
            conn.rollback()

    finally:
        # Ensure cursor and connection are closed
        if cursor:
            cursor.close()
        if conn:
            conn.close()
        context.log.info("Database connection closed.")
