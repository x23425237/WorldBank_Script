from dagster import job
from postg import create_database_and_tables  # Import the function that creates DB and tables
from extract import import_data
from load_data import load_loan_and_worldbank_data_to_postgres  # Import the function to load data into PostgreSQL



@job
def import_world_bank_data():

  # Step 1: Query API and load to MongoDB (returning CSV)
    csv_data = import_data()

  # Step 2: Connect to PostgreSQL and create tables
    connection = create_database_and_tables()

    
      # Step 3: Import data to PostgreSQL
    load_loan_and_worldbank_data_to_postgres(csv_data,connection)

