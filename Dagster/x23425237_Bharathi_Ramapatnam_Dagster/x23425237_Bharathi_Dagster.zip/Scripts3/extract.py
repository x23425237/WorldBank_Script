import pymongo
import requests
import pandas as pd
from pymongo.errors import ServerSelectionTimeoutError, OperationFailure, PyMongoError
from dagster import op
import os

# MongoDB client setup
mongoclient = 'mongodb://localhost:27017/'
# URL of the World Bank API
url = "https://datacatalogapi.worldbank.org/dexapps/fone/api/apiservice?datasetId=DS00047&resourceId=RS00049"

# Hard-coding database and collection names
MY_SAMPLE_DATABASE = "sampleDG"
COLLECTION_NAME = "sampledg"
output_csv="C:/Users/prana/Documents/NCI/PythonWorkSpace/WorldBank/Data/data_oct2024.csv"

@op
def import_data(context, serverSelectionTimeoutMS=5000, output_csv_path=output_csv):
    try:
        # Connect to the MongoDB server
        myclient = pymongo.MongoClient(mongoclient, serverSelectionTimeoutMS=serverSelectionTimeoutMS)

        # Attempt to get the server info to check the connection
        myclient.server_info()  # This will raise an error if the connection fails

        # List all databases
        existing_dbs = myclient.list_database_names()
        context.log.info(f"Databases: {existing_dbs}")

        if MY_SAMPLE_DATABASE not in existing_dbs:
            # Create a new database
            mydb = myclient[MY_SAMPLE_DATABASE]
            context.log.info(f"{MY_SAMPLE_DATABASE} created.")
        else:
            mydb = myclient[MY_SAMPLE_DATABASE]
            context.log.info(f"Database {MY_SAMPLE_DATABASE} already exists. Skipping creation.")

        # List existing collections
        existing_collections = mydb.list_collection_names()

        if COLLECTION_NAME not in existing_collections:
            # Create a new collection
            mycol = mydb[COLLECTION_NAME]
            context.log.info(f"Collection '{COLLECTION_NAME}' created.")

            # Fetch data from the API
            response = requests.get(url)

            # Check if the request was successful
            if response.status_code == 200:
                data = response.json()  # Parse the JSON response
                
                # Insert the data into the MongoDB collection
                if isinstance(data, list):
                    x = mycol.insert_many(data)  # Use insert_many for multiple records
                    context.log.info(f"Inserted document IDs: {x.inserted_ids}")
                else:
                    x = mycol.insert_one(data)  # Use insert_one if it's a single record
                    context.log.info(f"Inserted document ID: {x.inserted_id}")
            else:
                context.log.error(f"Failed to retrieve data: {response.status_code}")
        else:
            context.log.info(f"Collection '{COLLECTION_NAME}' already exists. Skipping creation.")

        # Convert the data to a pandas DataFrame (assuming the collection contains documents that can be represented as rows)
        mycol = mydb[COLLECTION_NAME]
        data = list(mycol.find())  # Retrieve all documents from the collection

        # Convert to DataFrame
        if data:
            df = pd.DataFrame(data)

            # Save to CSV
            df.to_csv(output_csv_path, index=False)
            context.log.info(f"Data exported to CSV at {output_csv_path}")
            return output_csv_path  # Return the path to the saved CSV file
        else:
            context.log.warning("No data found to export.")
            return None

    except ServerSelectionTimeoutError:
        context.log.error("Could not connect to the server within the timeout period. Please check the server address.")
    except OperationFailure as e:
        context.log.error(f"Operation failed: {e}")
    except PyMongoError as e:
        context.log.error(f"A MongoDB error occurred: {e}")
    except Exception as e:
        context.log.error(f"An unexpected error occurred: {e}")
    finally:
        myclient.close()  # Close the connection
